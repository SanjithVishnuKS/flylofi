Flylofi Focus Flight for Windows
=================================
A simulated in-flight deep focus study experience with lofi music and cabin ambience.

How to Run:
Double-click Flylofi.exe to launch in a clean, standalone desktop window.

Features:
- Dedicated desktop app window with no browser toolbar
- Isolated focus profile and local storage
- Full support for Flight, Car Night Drive, and Sleeper Bus
- Interactive tearable boarding pass and lofi audio suite

Web Version: https://focus-flight.always04king.workers.dev/
