#!/usr/bin/env bash
echo "Uninstalling Flylofi Focus Flight..."
rm -f "${HOME}/.local/bin/flylofi"
rm -f "${HOME}/.local/share/applications/flylofi.desktop"
rm -f "${HOME}/.local/share/icons/hicolor/512x512/apps/flylofi.png"
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "${HOME}/.local/share/applications" 2>/dev/null || true
fi
echo "Flylofi has been removed."
