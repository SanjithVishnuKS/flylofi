#!/usr/bin/env bash
# Flylofi Focus Flight — Linux Desktop Launcher
set -e

URL="https://focus-flight.always04king.workers.dev/"
PROFILE_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/flylofi/profile"
mkdir -p "$PROFILE_DIR"

# Candidates for dedicated app window mode
BROWSERS=(
    "google-chrome-stable"
    "google-chrome"
    "chromium-browser"
    "chromium"
    "brave-browser"
    "microsoft-edge-stable"
    "microsoft-edge"
    "zen-browser"
)

for b in "${BROWSERS[@]}"; do
    if command -v "$b" >/dev/null 2>&1; then
        exec "$b" --app="$URL" --user-data-dir="$PROFILE_DIR" --window-size=1280,820 "$@"
    fi
done

# Fallback to Firefox standalone window
if command -v firefox >/dev/null 2>&1; then
    exec firefox --new-window "$URL" "$@"
fi

# Fallback to system default handler
if command -v xdg-open >/dev/null 2>&1; then
    exec xdg-open "$URL"
fi

echo "[Flylofi] Please open $URL in your web browser."
