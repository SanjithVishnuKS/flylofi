# Flylofi Focus Flight for Linux

Simulated in-flight deep focus study experience with lofi music and cabin ambience.

## Quick Installation

Run the installation script in terminal:

```bash
chmod +x install.sh
./install.sh
```

This installs Flylofi to `~/.local/bin/flylofi` and registers the desktop icon in your application launcher (GNOME, KDE Plasma, XFCE, Cinnamon, etc.).

## Direct Run

```bash
chmod +x flylofi.sh
./flylofi.sh
```

## Uninstallation

```bash
chmod +x uninstall.sh
./uninstall.sh
```
