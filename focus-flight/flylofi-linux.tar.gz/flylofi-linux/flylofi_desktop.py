#!/usr/bin/env python3
"""Flylofi Focus Flight — Cross-Platform Python Desktop Launcher"""
import os
import sys
import subprocess
import webbrowser

URL = "https://focus-flight.always04king.workers.dev/"

def main():
    browsers = [
        'google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser',
        'brave-browser', 'microsoft-edge', 'microsoft-edge-stable'
    ]
    for b in browsers:
        try:
            subprocess.Popen([b, f'--app={URL}', '--window-size=1280,820'])
            return
        except FileNotFoundError:
            continue
        except Exception:
            pass

    webbrowser.open(URL)

if __name__ == '__main__':
    main()
