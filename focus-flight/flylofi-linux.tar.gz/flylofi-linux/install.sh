#!/usr/bin/env bash
set -e

echo "=================================================="
echo "  Installing Flylofi Focus Flight for Linux..."
echo "=================================================="

BIN_DIR="${HOME}/.local/bin"
APPS_DIR="${HOME}/.local/share/applications"
ICONS_DIR="${HOME}/.local/share/icons/hicolor/512x512/apps"

mkdir -p "$BIN_DIR" "$APPS_DIR" "$ICONS_DIR"

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copy binary launcher
cp "$DIR/flylofi.sh" "$BIN_DIR/flylofi"
chmod +x "$BIN_DIR/flylofi"

# Copy icon and desktop entry
cp "$DIR/icon-512.png" "$ICONS_DIR/flylofi.png"
cp "$DIR/flylofi.desktop" "$APPS_DIR/flylofi.desktop"
chmod +x "$APPS_DIR/flylofi.desktop"

# Update desktop database if available
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$APPS_DIR" 2>/dev/null || true
fi

echo ""
echo "Flylofi installed successfully!"
echo "  - Launch from your Linux application menu (search 'Flylofi')"
echo "  - Or run 'flylofi' from terminal (~/.local/bin/flylofi)"
echo "=================================================="
